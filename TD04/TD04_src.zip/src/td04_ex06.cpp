#include <iostream>

/*Même en utilisant que des entiers, le programme ne "remonte" pas le while, il divise encore par 2 même si le résultat devient impair / multiplie encore par 3 + 1 si le résultat devient pair */

int main()
{
    int tours{};
    int res{};
    unsigned int saisie{};

    std::cout << "Saisir un entier positif :" << std::endl;
    std::cin >> saisie;
    res = saisie;

    if (std::cin.fail()) {
        std::cout << "Erreur de saisie" << std::endl;
        std::cin.clear();
        std::cin.ignore(255, '\n');
        return 1; 
    
    } else {
        while (res!=1)
        {
            if (saisie%2==0) {
                res/=2;
                tours++;
                std::cout << res << std::endl;
            
            } else {
                res= res*3+1;
                tours++;
                std::cout << res << std::endl;
            }
        }
        std::cout << "Il y a " << tours << " termes pour atteindre 1" << std::endl;
    }
}