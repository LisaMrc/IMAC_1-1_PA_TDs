#include <iostream>

/*NB : je sais que cet exercice ne fonctionne pas, je ne sais juste pas comment l'agencer autrement pour l'instant*/

int main() {
    float montant{};
    
    std::cout << "Saisir le montant en euros:" << std::endl;
    std::cin >> montant;

    int nb_500;
    int nb_200;
    int nb_100;
    int nb_50;
    int nb_20;
    int nb_10;
    int nb_5;
    int nb_p_2;
    int nb_p_1;
    int nb_p_50;
    int nb_p_20;
    int nb_p_10;
    int nb_p_05;
    int nb_p_02;
    int nb_p_01;

    while (montant>500) {
        montant -= 500;
        nb_500++;
    }

    while (montant>200) {
        montant -= 200;
        nb_200++;
    }

    while (montant>100) {
        montant -= 100;
        nb_100++;
    }

    while (montant>50) {
        montant -= 50;
        nb_50++;
    }

    while (montant>20) {
        montant -= 20;
        nb_20++;
    }

    while (montant>10) {
        montant -= 10;
        nb_10++;
    }

    while (montant>5) {
        montant -= 5;
        nb_5++;
    }

    while (montant>2) {
        montant -= 2;
        nb_p_2++;
    }

    while (montant>1) {
        montant -= 1;
        nb_p_1++;
    }

    while (montant>.5){
        montant -= .5;
        nb_p_50++;
    }

    while (montant>.2) {
        montant -= .2;
        nb_p_20++;
    }

    while (montant>.1) {
        montant -= .1;
        nb_p_10++;
    }

    while (montant>.05) {
        montant -= .05;
        nb_p_05++;
    }

    while (montant>.02) {
        montant -= .02;
        nb_p_02++;
    }

    while (montant>.02) {
        montant -= .02;
        nb_p_02++;
    }

    while (montant>.01) {
        montant -= .01;
        nb_p_01++;
    }

    std::cout << "L'appareil rend :" << std::endl;
    std::cout << nb_500 << " billet(s) de 500," << std::endl;
    std::cout << nb_200 << " billet(s) de 200," << std::endl;
    std::cout << nb_100 << " billet(s) de 100," << std::endl;
    std::cout << nb_50 << " billet(s) de 50," << std::endl;
    std::cout << nb_20 << " billet(s) de 20," << std::endl;
    std::cout << nb_10 << " billet(s) de 10," << std::endl;
    std::cout << nb_5 << " billet(s) de 5," << std::endl;
    std::cout << "et" << std::endl;
    std::cout << nb_p_2 << " piece(s) de 2" << std::endl;
    std::cout << nb_p_1 << " piece(s) de 1" << std::endl;
    std::cout << nb_p_50 << " piece(s) de 50 cts" << std::endl;
    std::cout << nb_p_20 << " piece(s) de 20 cts" << std::endl;
    std::cout << nb_p_10 << " piece(s) de 10 cts" << std::endl;
    std::cout << nb_p_05 << " piece(s) de 5 cts" << std::endl;
    std::cout << nb_p_02 << " piece(s) de 2 cts" << std::endl;
    std::cout << nb_p_02 << " piece(s) de 1 ct" << std::endl;
}